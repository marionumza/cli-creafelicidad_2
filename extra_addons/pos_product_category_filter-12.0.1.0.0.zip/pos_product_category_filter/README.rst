===============================
POS Product Category Filter V12
===============================

This module shows only the specified categories of products in Point of Sale.

Depends
=======

[point_of_sale] addon Odoo


Installation
============

- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon


Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>


Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.

