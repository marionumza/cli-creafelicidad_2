Odoo 11.0

Installation 
============
* Install the Application => Apps -> User Activity Log (Technical Name: user_recent_log)



User Activity Log
==================================
* This module will show the activity done by the users. It will record modification of user.


Steps
=====
* Click on User tab on top right corner, A drop down will open and select the option Recent logs and select the record that you want to see.



